// submit.js

export const SubmitButton = () => {
  return (
    <div className="flex items-center justify-center">
      <button type="submit">Submit</button>
    </div>
  );
};
